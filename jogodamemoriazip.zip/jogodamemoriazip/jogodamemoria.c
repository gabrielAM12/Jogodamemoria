#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include <string.h>
 /* 
 
 MENU:
 	JOGAR:
 		COLOCAR NO ARRAY NOME OS NOMES DIGITADOS PELO USU�RIO
 		CRIAR UMA MATRIZ COM ALOCA��O DIN�MICA
 		COLOCAR N�MEROS ALEAT�RIOS NA MATRIZ
 		COLOCAR UM TEMPORIZADOR PARA OS N�MEROS SEREM EXIBIDOS
 		MOSTRAR A POSI��O DA RESPOSTA EM LINHA E COLUNA
 		CRIAR UM CONTADOR DOS ACERTOS DE CADA JOGADOR E EXIBIR O NOME DO JOGADOR JUNTO COM O N�MERO DE ACERTOS
 		SE ALGUM JOGADOR APERTAR ENTER O PROGRAMA IRA VOLTAR PARA O MENU
 		
 		
 		
 		
 		
	VER RANKING
		UTILIZAR O RETURN DO N�MERO DE ACERTOS DA FUN��O JOGAR PARA ARMAZENAR O N�MERO DE ACERTOS
		AO SELECIONAR ESSA OP��O EXIBIR UMA TELA COM O NOME DO JOGADOR PEDIDO NO IN�CIO DO JOGO E MOSTRAR QUANTOS ACERTOS ELE FEZ
	CREDITOS
		UTILIZAR UMA FUNCAO VOID PARA MOSTRAR O TEXTO
		SE APERTAR ALGUMA TECLA O JOGADOR VOLTAR� PARA O MENU
	SAIR
		AO SELECIONAR ESSA OP��O O PROGRAMA SER� ENCERRADO 
 
 
 
 */
 
 // Fun��o para exibir a tela de menu do jogo e op��es de escolha
 void menu(){
 	system("cls");
 	// SA�DA:
 	printf("\nJOGO DA MEM�RIA\n\n");
 	printf("1-Jogar \n2-Ver Ranking \n3-Cr�ditos \n4-Sair ");
 }
 
 
 // Fun��o principal para iniciar o jogo
 int jogar(char nome[100]){
 	// PROCESSAMENTO:
 	srand(time(NULL));//semente para gerar os n�meros aleat�rios
 	system("cls"); //comando para limpar a tela
 	int l = 0, c = 0, temporizador = 25, acertos = 0; // l= linha, c= coluna, temporizador= tempo em segundos em que os n�meros ser�o exibidos
 	
 	
     
     
    
    // instru��o para formar uma matriz 4 x 4, com n�meros aleat�rios entre 1 e 40.
    int ** numeros = (int **) malloc( sizeof(int*)*4 );
	// PROCESSAMENTO:
    for (l=0 ; l<4 ; l++) {

		//n�meros que ser�o gerados automaticamente
        numeros[l] = (int *) malloc(sizeof(int) * 4);
        for (c=0 ; c<4 ; c++) {
            numeros[l][c] = (rand() % 40)+1;
        }
    }
    
    

    
    
    
    // Continuar exibindo os n�meros na tela enquanto o tempo em segundos for maior que zero.
    
    do{
        system ("cls");
        // SA�DA:
        printf ("Tente acertar os numeros abaixo em %d\n\n\n", temporizador);
        temporizador--;
        for (l=0;l<4;l++){
        	printf("\t\t");
	 		for (c=0;c<4;c++){
	 			printf ("%d\t", numeros[l][c]);
			}
			printf("\n\n");   
	    } 
        Sleep (1000);
    }while (temporizador>0);
    // limpar a tela para que os n�meros n�o continuem sendo exibidos ap�s o tempo acabar
    system ("cls");
    // SA�DA:
    printf ("Informe os n�meros que foram exibidos\n\n");
    
    
    
    //respostas digitadas pelo usu�rio
    int ** respostas = (int **) malloc( sizeof(int*)*4 );
	// Verificar os n�meros digitados por linha e coluna e ao acertar o resultado, acrescentar 1 no contador de acertos.
	
    for (l=0 ; l<4 ; l++) {


        respostas[l] = (int *) malloc(sizeof(int) * 4);
        for (c=0 ; c<4 ; c++) {
            printf ("\tn�mero da %d� linha e %d� coluna : ", l+1,c+1); 
        	scanf ("%d", &respostas[l][c]); // ENTRADA: RECEBE DO USU�RIO OS N�MEROS CORRESPONDENTES A LINHA E COLUNA
        	// PROCESSAMENTO: 
        	if (respostas[l][c]==numeros[l][c]){
            	acertos++;
        	}
    	}
	}
    if (acertos!=0){
    	printf("Parab�ns %s! Voc� acertou %d n�meros. Os n�meros eram:\n\n",nome,acertos); // SA�DA
	}
	else{
		printf("Que pena %s.Voc� n�o acertou nenhum n�mero.\n\n",nome); // SA�DA
	}
    // SA�DA: exibir mais uma vez a mesma sequ�ncia de n�meros, para o usu�rio verificar seus erros e acertos
	for (l=0;l<4;l++){
		printf("\t\t");
 		for (c=0;c<4;c++){
 			printf ("%d\t", numeros[l][c]);
		}
		printf("\n\n");   
    }
    // PROCESSAMENTO: 
    if (numeros!=NULL) {
        for (l=0 ; l<4 ; l++) {
            if (numeros[l] != NULL)
                free(numeros[l]);
        }
        free(numeros);
    }
	// PROCESSAMENTO: 
	if (respostas!=NULL) {
        for (l=0 ; l<4 ; l++) {
            if (respostas[l] != NULL)
                free(respostas[l]);
        }
        free(respostas);
    }


    printf ("\n\n");
    system ("pause");
    return acertos;

}
 int jogar2(char nome2[100]){
 	// PROCESSAMENTO:
 	srand(time(NULL));//semente para gerar os n�meros aleat�rios
 	system("cls"); //comando para limpar a tela
 	int l = 0, c = 0, temporizador = 25, acertos2 = 0; // l= linha, c= coluna, temporizador= tempo em segundos em que os n�meros ser�o exibidos
 	
 	
     
     
    
    // instru��o para formar uma matriz 4 x 4, com n�meros aleat�rios entre 1 e 40.
    int ** numeros = (int **) malloc( sizeof(int*)*4 );
	// PROCESSAMENTO:
    for (l=0 ; l<4 ; l++) {

		//n�meros que ser�o gerados automaticamente
        numeros[l] = (int *) malloc(sizeof(int) * 4);
        for (c=0 ; c<4 ; c++) {
            numeros[l][c] = (rand() % 40)+1;
        }
    }
    
    

    
    
    
    // Continuar exibindo os n�meros na tela enquanto o tempo em segundos for maior que zero.
    
    do{
        system ("cls");
        // SA�DA:
        printf ("Tente acertar os numeros abaixo em %d\n\n\n", temporizador);
        temporizador--;
        for (l=0;l<4;l++){
        	printf("\t\t");
	 		for (c=0;c<4;c++){
	 			printf ("%d\t", numeros[l][c]);
			}
			printf("\n\n");   
	    } 
        Sleep (1000);
    }while (temporizador>0);
    // limpar a tela para que os n�meros n�o continuem sendo exibidos ap�s o tempo acabar
    system ("cls");
    // SA�DA:
    printf ("Informe os n�meros que foram exibidos\n\n");
    
    
    
    //respostas digitadas pelo usu�rio
    int ** respostas = (int **) malloc( sizeof(int*)*4 );
	// Verificar os n�meros digitados por linha e coluna e ao acertar o resultado, acrescentar 1 no contador de acertos.
	
    for (l=0 ; l<4 ; l++) {


        respostas[l] = (int *) malloc(sizeof(int) * 4);
        for (c=0 ; c<4 ; c++) {
            printf ("\tn�mero da %d� linha e %d� coluna : ", l+1,c+1); 
        	scanf ("%d", &respostas[l][c]); // ENTRADA: RECEBE DO USU�RIO OS N�MEROS CORRESPONDENTES A LINHA E COLUNA
        	// PROCESSAMENTO: 
        	if (respostas[l][c]==numeros[l][c]){
            	acertos2++;
        	}
    	}
	}
    if (acertos2!=0){
    	printf("Parab�ns %s! Voc� acertou %d n�meros. Os n�meros eram:\n\n",nome2,acertos2); // SA�DA
	}
	else{
		printf("Que pena %s.Voc� n�o acertou nenhum n�mero.\n\n",nome2); // SA�DA
	}
    // SA�DA: exibir mais uma vez a mesma sequ�ncia de n�meros, para o usu�rio verificar seus erros e acertos
	for (l=0;l<4;l++){
		printf("\t\t");
 		for (c=0;c<4;c++){
 			printf ("%d\t", numeros[l][c]);
		}
		printf("\n\n");   
    }
    // PROCESSAMENTO: 
    if (numeros!=NULL) {
        for (l=0 ; l<4 ; l++) {
            if (numeros[l] != NULL)
                free(numeros[l]);
        }
        free(numeros);
    }
	// PROCESSAMENTO: 
	if (respostas!=NULL) {
        for (l=0 ; l<4 ; l++) {
            if (respostas[l] != NULL)
                free(respostas[l]);
        }
        free(respostas);
    }


    printf ("\n\n");
    
    return acertos2;

}


// Fun��o para exibir os cr�ditos de desenvolvimento do algoritmo
 void creditos(){
 	system("cls");
 	// SA�DA:
 	printf("\nProjeto Conjunto TDA e LDA\n");
 	printf("Jogo da mem�ria\n");
 	printf("Alunos: Gabriel de Almeida Mangueira e \nVictor de Almeida Mangueira.\n");
 	
 }
 
 
 
 
int main(){ 
    //vari�veis
    char c;
    char nome[100];
    char nome2[100];
    int sair=0;
    int acertos=0;
    int acertos2=0;
    //comando de regionaliza��o
    setlocale(LC_ALL, "Portuguese");
    //t�tulo do programa
    SetConsoleTitle("Jogo da memoria");
    
    
    // Comandos para pegar do teclado os n�meros do menu digitados pelo usu�rio de acordo com a tabela ASCII
    // Tratamento de erros para n�o crashar o programa se o usu�rio digitar uma op��o inv�lida
    while (sair==0){
    
    	menu();
    	
    	do{
    		c = getch(); // ENTRADA: receber do jogador o n�mero correspondente a op��o do menu, ex: 1-para iniciar o jogo
		}while (c!=49 && c!=50 && c!=51 && c!=52);//jogar|ver ranking|creditos|sair
    
    	
    	if (c==49){
			system("cls");
			// ENTRADA: Receber o nome do jogador
    		printf("Digite o nome do jogador 1: ");
    		scanf("%s",nome);
			acertos=jogar(nome);
			system("cls");
			printf("Digite o nome do jogador 2: ");
    		scanf("%s",nome2);
			acertos2=jogar2(nome2);
    		if (acertos> acertos2){
    			printf("O jogador %s com %d acertos, ganhou do jogador %s que fez %d acertos\n\n",nome,acertos,nome2,acertos2); //SA�DA
    			system("pause");
			}else if (acertos2 > acertos){
				printf("O jogador %s com %d acertos, ganhou do jogador %s que fez %d acertos\n\n",nome2,acertos2,nome,acertos); //SA�DA
				system("pause");
			}else{
				printf("Empate! Os dois jogadores acertaram %d n�meros\n\n",acertos); //SA�DA
				system("pause");
			}
		}
		
		else if(c==50){
			system("cls");
			// SA�DA: Mostrar o nome do jogador e o n�mero de acertos, ap�s a op��o ranking ter sido selecionada.
			if (acertos> acertos2){
				printf("%s: %d acertos\n",nome,acertos);
				printf("%s: %d acertos\n",nome2,acertos2);
				system("pause");
			}
			else{
				printf("%s: %d acertos\n",nome2,acertos2);
				printf("%s: %d acertos\n",nome,acertos);
				system("pause");
			}
		}
		// PROCESSAMENTO:
		else if(c==51){
			creditos();
			getch();
		}
		// PROCESSAMENTO: 
		else if(c==52){
			sair=1;
    		

		}
	}
    
    return 0;
}
